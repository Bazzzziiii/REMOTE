# LG NAT PLUS Remote — Android source project

A small native Android app intended to test infrared commands on an LG DH3140S DVD Home Theater. It includes a prominent **SOUND EFFECT → NAT PLUS** button, volume, mute, playback, function, left/right/enter, two possible LG IR command profiles, two signal timings, infrared-hardware detection, and an advanced editable IR-code screen. Uses Android `ConsumerIrManager` and requires no internet permissions.

## Important limitations

- **This is an experimental app, not a verified DH3140S remote.** The infrared codes came from **other** LG players. The app may not work on the DH3140S without the exact IR codes.
- NAT PLUS is **not** a known dedicated IR command. The large NAT PLUS button sends the candidate **SOUND EFFECT** command **once**; if the LG responds, press it repeatedly to cycle sound modes until the player displays NAT PLUS.
- The phone must have an Android-accessible IR transmitter. Infinix's hardware may be controlled by a proprietary WeLife driver unavailable to third-party apps. The app detects if the Android infrared interface is accessible.
- Sound effects do not repair damaged amp channels. Check exposed speaker wires before applying power. Never join the output channels' positive or negative terminals together.
- No APK was compiled in this workspace because the Android SDK/build toolchain is unavailable. To obtain an APK, use GitHub Actions or Android Studio as described below.

## Get an APK for your phone — GitHub method

1. Extract the ZIP on a PC. Open the `LG_NAT_PLUS_Remote` folder.
2. Create a **new private GitHub repository** (for example `LG-NAT-PLUS-Remote`).
3. Upload **all extracted project files**, including the `.github/workflows/build-apk.yml` folder and the `app` folder, to the root of that repository. On Windows hidden `.github` is a normal folder; you can see it in File Explorer when extracted.
4. Click **Actions** → **Build Android APK** → **Run workflow** (or check its automatic first build).
5. Open the successful workflow → **Artifacts** → download **LG-NAT-PLUS-Remote-debug-APK**.
6. Unzip the artifact and transfer `app-debug.apk` to your phone. Install only your own APK. Android may ask you to allow installations from Files for this one download.

The workflow uses GitHub-hosted Android build tools, so you don't need Android Studio to build it this way. The workflow requires Actions to be enabled for your repository.

## Build with Android Studio

1. Open this project folder in Android Studio, configured for JDK 17 and Android SDK Platform 35.
2. Configure it to use **Gradle 8.9** (the source includes Gradle wrapper properties but not the wrapper JAR; an installed Gradle 8.9 also works).
3. Run `gradle assembleDebug` or select **Build → Build APK(s)** after successful Gradle sync.
4. Find `app/build/outputs/apk/debug/app-debug.apk`.

## How to try it

1. Ensure speaker wiring is inspected and safe BEFORE powering the LG on.
2. Launch the app. Read its IR status. If Android does not expose IR on the phone, this app cannot transmit (even if WeLife works).
3. Choose **LG 5.1 / Blu-ray** profile, **Samsung 32** timing.
4. With the LG turned on and volume low, aim the top of the phone at it and press **VOL + once**. Check the physical LG display/volume. No response? Try the **LG DVD / Theater** profile, then **NEC 32** timing.
5. When a profile responds to VOL +, tap the green **SOUND EFFECT → NAT PLUS** button, one press at a time. If the display changes sound modes, stop when it shows **NAT PLUS**.
6. If nothing works, you need a verified LG DH3140S infrared capture or a compatible remote; do not assume the player is faulty based only on these experimental profiles.

## Code references (NOT exact model verification)

- LG DH3140S owner manual: https://manualzz.com/doc/51532182/lg-dh3140s-owner-s-manual
- LG 5.1 Blu-ray IR list (Sound Effect `3434F40B`, Volume+ `3434E817`): https://gist.github.com/fyra/256d158e8bc83016620845636d9746f3
- LG LH-T3600 DVD receiver IR list (Sound `3434857A`, buttons): https://github.com/irplus-remote/irplus-codes.github.io/issues/776
- Infinix X6851B official product information documents IR hardware: https://ph-ec-test.infinixmobility.com/specs/note-40-pro%2B-5g

No affiliation with LG or Infinix. No tracking, ads, or network permissions.
