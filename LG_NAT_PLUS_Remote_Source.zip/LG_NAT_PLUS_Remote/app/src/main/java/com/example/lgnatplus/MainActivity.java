package com.example.lgnatplus;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 16, 27);
    private static final int PANEL = Color.rgb(23, 33, 49);
    private static final int TEXT = Color.rgb(240, 246, 255);
    private static final int MUTED = Color.rgb(167, 183, 202);
    private static final int ACCENT = Color.rgb(93, 220, 184);
    private static final int OUTLINE = Color.rgb(55, 73, 96);
    private final String[] keys = { "sound", "volUp", "volDown", "mute", "function", "play", "stop", "prev", "next", "left", "right", "ok" };
    private final String[] labels = { "SOUND EFFECT", "VOL +", "VOL -", "MUTE", "FUNCTION", "PLAY", "STOP", "PREV", "NEXT", "LEFT", "RIGHT", "OK" };
    // Tested by owners of different LG systems, NOT verified on DH3140S.
    private final String[] common = { "3434F40B", "3434E817", "34346897", "3434F807", "343451AE", "343420DF", "3434A05F", "3434609F", "3434E01F", "343415EA", "3434956A", "343455AA" };
    private ConsumerIrManager ir;
    private SharedPreferences prefs;
    private int profile;
    private boolean samsung;
    private TextView feedback;
    private TextView hardware;
    private Button profileA;
    private Button profileB;
    private Button samsungButton;
    private Button necButton;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("remote", MODE_PRIVATE);
        profile = prefs.getInt("profile", 0);
        samsung = prefs.getBoolean("samsung", true);
        ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        render();
    }

    private int dp(float d) { return Math.round(getResources().getDisplayMetrics().density * d); }

    private GradientDrawable round(int color, int border, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        if (border != 0) g.setStroke(dp(1), border);
        return g;
    }

    private LinearLayout column() {
        LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.VERTICAL); return v;
    }
    private LinearLayout row() {
        LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.HORIZONTAL); v.setGravity(Gravity.CENTER_VERTICAL); return v;
    }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }
    private void add(LinearLayout parent, View child, int marginTop) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(marginTop); parent.addView(child, p);
    }
    private LinearLayout section(String name, String subtitle) {
        LinearLayout card = column();
        card.setPadding(dp(17),dp(17),dp(17),dp(17)); card.setBackground(round(PANEL, OUTLINE, 18));
        add(card,text(name,19,TEXT,true),0);
        if (subtitle != null) add(card,text(subtitle,13,MUTED,false),6);
        return card;
    }
    private Button button(String label, int bgColor, int fgColor, int size) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(size); b.setAllCaps(false);
        b.setTextColor(fgColor); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(round(bgColor, bgColor==ACCENT ? 0 : OUTLINE, 12));
        b.setMinHeight(dp(54));
        b.setPadding(dp(8),dp(10),dp(8),dp(10));
        return b;
    }
    private void dual(LinearLayout dest, Button a, Button b) {
        LinearLayout r=row();
        LinearLayout.LayoutParams lpA=new LinearLayout.LayoutParams(0, dp(56),1f);
        lpA.rightMargin=dp(6); r.addView(a,lpA);
        LinearLayout.LayoutParams lpB=new LinearLayout.LayoutParams(0, dp(56),1f);
        lpB.leftMargin=dp(6); r.addView(b,lpB);
        add(dest,r,12);
    }
    private Button action(String label, String key) {
        Button b=button(label, Color.rgb(34,50,69), TEXT,14);
        b.setOnClickListener(v -> send(key)); return b;
    }
    private void render() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout root = column(); root.setPadding(dp(18), dp(25), dp(18), dp(36));
        scroll.addView(root); setContentView(scroll);
        add(root,text("LG SPEAKER REMOTE",12,ACCENT,true),0);
        add(root,text("NAT PLUS Controller",29,TEXT,true),4);
        add(root,text("For LG DH3140S  •  IR remote experiment",13,MUTED,false),3);

        hardware=text("Checking infrared...",13,TEXT,true);
        LinearLayout state=section("Phone infrared",null); add(state,hardware,10); add(root,state,17);
        checkHardware();

        LinearLayout main=section("Surround sound", "NAT PLUS is a mode, not a separate infrared command.");
        Button nat = button("SOUND EFFECT  →  NAT PLUS",ACCENT,BG,17);
        nat.setMinHeight(dp(76));
        nat.setOnClickListener(v -> send("sound"));
        add(main,nat,15);
        add(main,text("Press repeatedly while watching the LG display. Stop when it shows NAT PLUS.",13,MUTED,false),10);
        add(root,main,14);

        LinearLayout test=section("1  Test the connection", "Try VOL + once. If the LG reacts, the selected IR profile may be compatible.");
        dual(test,action("VOL −", "volDown"),action("VOL +","volUp"));
        dual(test,action("MUTE","mute"),action("FUNCTION","function"));
        add(root,test,14);

        LinearLayout profiles=section("2  Choose an LG IR profile", "These are codes reported for OTHER LG systems, not verified for DH3140S.");
        profileA=button("LG 5.1 / Blu-ray",PANEL,TEXT,13);
        profileB=button("LG DVD / Theater",PANEL,TEXT,13);
        profileA.setOnClickListener(v -> setProfile(0));
        profileB.setOnClickListener(v -> setProfile(1));
        dual(profiles,profileA,profileB);
        add(profiles,text("If VOL + doesn't respond, try the second profile or transmission timing below.",12,MUTED,false),8);
        add(root,profiles,14);

        LinearLayout codes=section("3  Signal type", "Different LG receivers can use different timings.");
        samsungButton=button("Samsung 32 (4.5ms)",PANEL,TEXT,12);
        necButton=button("NEC 32 (9ms)",PANEL,TEXT,12);
        samsungButton.setOnClickListener(v -> setSignal(true));
        necButton.setOnClickListener(v -> setSignal(false));
        dual(codes,samsungButton,necButton);
        add(root,codes,14);

        LinearLayout more=section("Playback & menu",null);
        dual(more,action("◀◀ PREV","prev"),action("NEXT ▶▶","next"));
        dual(more,action("▶ PLAY","play"),action("■ STOP","stop"));
        dual(more,action("◀ LEFT","left"),action("RIGHT ▶","right"));
        Button ok=action("OK / ENTER", "ok"); add(more,ok,12);
        add(root,more,14);

        LinearLayout advanced=section("Advanced: enter verified IR codes", "If you obtain a DH3140S IR code, paste its 8 hex digits here.");
        Button editor=button("Edit button IR codes",Color.rgb(34,50,69),TEXT,14);
        editor.setOnClickListener(v -> editCode()); add(advanced,editor,13);
        add(root,advanced,14);

        LinearLayout msg=section("App status",null);
        feedback=text("Ready. Aim the top of your phone at the LG player.",13,MUTED,false);
        add(msg,feedback,9); add(root,msg,14);
        add(root,text("Safety: never combine speaker wires onto one output. Repair loose / exposed wire connections before turning on the amplifier.",12,Color.rgb(242,183,137),false),15);
        refreshOptions();
    }
    private void checkHardware() {
        try {
            if (ir != null && ir.hasIrEmitter()) {
                hardware.setText("IR transmitter available to this app"); hardware.setTextColor(ACCENT);
            } else {
                hardware.setText("IR not accessible through Android. WeLife may use a proprietary driver, so this app may not transmit.");
                hardware.setTextColor(Color.rgb(255,195,109));
            }
        } catch(Exception e) {
            hardware.setText("IR check failed: " + e.getMessage());
            hardware.setTextColor(Color.rgb(255,195,109));
        }
    }
    private void setProfile(int p) {
        profile = p; prefs.edit().putInt("profile",profile).apply(); refreshOptions();
        feedback.setText("Profile changed. Test VOL + first.");
    }
    private void setSignal(boolean s) {
        samsung = s; prefs.edit().putBoolean("samsung",samsung).apply(); refreshOptions();
        feedback.setText("Signal timing changed. Test VOL + first.");
    }
    private void refreshOptions() {
        profileA.setBackground(round(profile==0 ? ACCENT : Color.rgb(34,50,69),0,12));
        profileA.setTextColor(profile==0 ? BG : TEXT);
        profileB.setBackground(round(profile==1 ? ACCENT : Color.rgb(34,50,69),0,12));
        profileB.setTextColor(profile==1 ? BG : TEXT);
        samsungButton.setBackground(round(samsung ? ACCENT : Color.rgb(34,50,69),0,12));
        samsungButton.setTextColor(samsung ? BG : TEXT);
        necButton.setBackground(round(!samsung ? ACCENT : Color.rgb(34,50,69),0,12));
        necButton.setTextColor(!samsung ? BG : TEXT);
    }
    private String defaultCode(String key) {
        for(int i=0; i<keys.length; i++) {
            if (keys[i].equals(key)) return key.equals("sound") && profile==1 ? "3434857A" : common[i];
        }
        return "";
    }
    private String code(String key) {
        return prefs.getString("cmd_"+profile+"_"+key,defaultCode(key));
    }
    private void send(String key) {
        String command=code(key);
        try {
            if (ir==null || !ir.hasIrEmitter()) {
                feedback.setText("Cannot transmit: Android cannot access IR hardware on this phone.");
                Toast.makeText(this,"IR not accessible",Toast.LENGTH_LONG).show(); return;
            }
            int[] waveform = IrProtocol.pattern(command,samsung);
            ir.transmit(38000,waveform);
            if (key.equals("sound")) feedback.setText("SOUND EFFECT sent ("+command+"). Watch the LG display. Repeat until NAT PLUS, if your LG responded.");
            else feedback.setText(key.toUpperCase()+" infrared transmitted ("+command+"). This does not confirm the LG received it.");
        } catch (Exception e) {
            feedback.setText("IR send failed: "+e.getMessage());
            Toast.makeText(this,"IR command failed",Toast.LENGTH_SHORT).show();
        }
    }
    private void editCode() {
        String[] display = labels;
        Spinner spinner = new Spinner(this);
        spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,display));
        EditText hex=new EditText(this);
        hex.setSingleLine(true); hex.setTextColor(Color.BLACK); hex.setHint("3434F40B");
        hex.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        LinearLayout content=column(); content.setPadding(dp(16),dp(4),dp(16),0);
        add(content,text("Pick a button",14,Color.DKGRAY,false),0);
        add(content,spinner,8);
        add(content,text("8-digit IR frame, hexadecimal",14,Color.DKGRAY,false),10);
        add(content,hex,7);
        spinner.setSelection(0);
        hex.setText(code(keys[0]));
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View v, int pos, long id) { hex.setText(code(keys[pos])); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        new AlertDialog.Builder(this).setTitle("IR code editor").setView(content)
            .setPositiveButton("Save",(dlg,which)->{
                String value=hex.getText().toString().trim().toUpperCase().replace("0X","").replaceAll("\\s","");
                if(!value.matches("[0-9A-F]{8}")) {
                    Toast.makeText(this,"Not saved: use 8 hex digits",Toast.LENGTH_LONG).show(); return;
                }
                String key=keys[spinner.getSelectedItemPosition()];
                prefs.edit().putString("cmd_"+profile+"_"+key,value).apply();
                feedback.setText(labels[spinner.getSelectedItemPosition()]+" code updated to "+value);
            })
            .setNeutralButton("Reset selected", (dlg,which)->{
                String key=keys[spinner.getSelectedItemPosition()];
                prefs.edit().remove("cmd_"+profile+"_"+key).apply();
                feedback.setText("Reset "+key+" code to profile default.");
            })
            .setNegativeButton("Cancel",null).show();
    }
}
