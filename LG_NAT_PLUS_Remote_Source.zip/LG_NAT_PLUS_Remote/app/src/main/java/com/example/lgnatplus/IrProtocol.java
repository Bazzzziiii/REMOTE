package com.example.lgnatplus;

import java.util.ArrayList;
import java.util.List;

/** Creates Android ConsumerIrManager on/off periods in microseconds. */
public final class IrProtocol {
    private IrProtocol() { }

    /**
     * Samsung 32 (4500/4500) and NEC (9000/4500), MSB-first, both 38kHz.
     * Codes are the full 32-bit frames as printed in LG IR references (e.g. 3434E817).
     * Different receivers may expect an alternative encoding; this app makes the
     * transport selectable rather than claiming a model-specific verified code.
     */
    public static int[] pattern(String fullHexCode, boolean samsungStyle) {
        String clean = fullHexCode.toUpperCase().replace("0X", "").replaceAll("\\s", "");
        if (!clean.matches("[0-9A-F]{8}")) throw new IllegalArgumentException("Enter exactly 8 hex digits, e.g. 3434F40B");
        long frame = Long.parseLong(clean, 16);
        List<Integer> parts = new ArrayList<>();
        parts.add(samsungStyle ? 4500 : 9000);
        parts.add(4500);
        for (int bit = 31; bit >= 0; bit--) {
            parts.add(560);
            parts.add(((frame >>> bit) & 1L) == 1L ? 1690 : 560);
        }
        parts.add(560);
        int[] result = new int[parts.size()];
        for (int i = 0; i < parts.size(); i++) result[i] = parts.get(i);
        return result;
    }
}
